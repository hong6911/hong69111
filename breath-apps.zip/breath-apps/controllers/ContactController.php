<?php
namespace app\controllers;

use app\base\Controller;

class ContactController extends Controller
{
	public function actionIndex()
	{
	}
}