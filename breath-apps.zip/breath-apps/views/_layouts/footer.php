</body>

	<!-- Placed at the end of the document so the pages load faster -->
	<script src="<?php echo URL_BASE;?>/assets/scripts/jquery.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/scripts/modernizr.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/mCustomScrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/nprogress/nprogress.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/sweet-alert/sweetalert.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/waves/waves.min.js"></script>

	<!-- Morris Chart -->
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/morris/morris.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/morris/raphael-min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/scripts/chart.morris.black.init.min.js"></script>

	<!-- Flot Chart -->
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/plot/jquery.flot.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/plot/jquery.flot.tooltip.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/plot/jquery.flot.categories.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/plot/jquery.flot.pie.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/plot/jquery.flot.stack.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/scripts/chart.flot.black.init.min.js"></script>

	<!-- Sparkline Chart -->
	<script src="<?php echo URL_BASE;?>/assets/plugin/chart/sparkline/jquery.sparkline.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/scripts/chart.sparkline.init.min.js"></script>

	<!-- FullCalendar -->
	<script src="<?php echo URL_BASE;?>/assets/plugin/moment/moment.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/plugin/fullcalendar/fullcalendar.min.js"></script>
	<script src="<?php echo URL_BASE;?>/assets/scripts/fullcalendar.init.js"></script>

	<script src="<?php echo URL_BASE;?>/assets/scripts/main.min.js"></script>
	<!-- kendo date time picker and feeling point range -->
	<script src="<?php echo URL_BASE;?>/assets/scripts/kendo.all.min.js"></script>



</html>